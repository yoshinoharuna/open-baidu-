function onTabClick(showing, hiding) {
    $('#' + hiding).hide();
    $('#' + showing).show();
}